chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'downloadExcel') {
        const data = message.data;
        const csvContent = convertToCSV(data);
        downloadCSV(csvContent);
    }
});

function convertToCSV(data) {
    const headers = Object.keys(data[0]);
    const csvRows = [];
    csvRows.push(headers.join(','));

    data.forEach(item => {
        const values = headers.map(header => JSON.stringify(item[header] || ''));
        csvRows.push(values.join(','));
    });

    return csvRows.join('\n');
}

function downloadCSV(content) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
        url: url,
        filename: 'temu_products.csv'
    });
}
