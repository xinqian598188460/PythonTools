function scrapeProductData() {
    const products = [];
    document.querySelectorAll('.js-goods-list').forEach((item) => {
        const product = {
            title: item.querySelector('.product-title').innerText,
            price: item.querySelector('.product-price').innerText,
            link: item.querySelector('a').href,
            image: item.querySelector('img').src
        };
        products.push(product);
    });
    
    chrome.runtime.sendMessage({ type: 'downloadExcel', data: products });
}

scrapeProductData();
